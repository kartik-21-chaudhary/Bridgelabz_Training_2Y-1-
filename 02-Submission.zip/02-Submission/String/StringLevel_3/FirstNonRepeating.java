package StringLevel_3;
import java.util.Scanner;

public class FirstNonRepeating {

    static char findFirst(String text) {

        int[] frequency = new int[256];

        for (int i = 0; i < text.length(); i++) {
            frequency[text.charAt(i)]++;
        }

        for (int i = 0; i < text.length(); i++) {

            if (frequency[text.charAt(i)] == 1) {
                return text.charAt(i);
            }
        }

        return '\0';
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter text: ");
        String text = sc.nextLine();

        char result = findFirst(text);

        if (result == '\0')
            System.out.println("No non-repeating character");
        else
            System.out.println("First non-repeating character: " + result);
    }
}