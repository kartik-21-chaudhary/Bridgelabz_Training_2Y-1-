package StringLevel_2;
import java.util.Scanner;

public class VowelConsonant {

    static String checkCharacter(char c) {

        if (c >= 'A' && c <= 'Z') {
            c = (char)(c + 32);
        }

        if (c == 'a' || c == 'e' || c == 'i'
                || c == 'o' || c == 'u') {
            return "Vowel";
        }

        if (c >= 'a' && c <= 'z') {
            return "Consonant";
        }

        return "Not a Letter";
    }

    static int[] countVowelsConsonants(String text) {

        int vowels = 0;
        int consonants = 0;

        for (int i = 0; i < text.length(); i++) {

            String result = checkCharacter(text.charAt(i));

            if (result.equals("Vowel"))
                vowels++;

            if (result.equals("Consonant"))
                consonants++;
        }

        return new int[]{vowels, consonants};
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter text: ");
        String text = sc.nextLine();

        int[] result = countVowelsConsonants(text);

        System.out.println("Vowels: " + result[0]);
        System.out.println("Consonants: " + result[1]);
    }
}