package ArrayLevel_2;
import java.util.*;

public class BMI2D {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter number of persons: ");
        int n=sc.nextInt();

        double[][] personData=new double[n][3];
        String[] weightStatus=new String[n];

        for(int i=0;i<n;i++){
            do{
                System.out.print("Enter weight (kg): ");
                personData[i][0]=sc.nextDouble();
                if(personData[i][0]<=0)
                    System.out.println("Enter positive value");
            }while(personData[i][0]<=0);

            do{
                System.out.print("Enter height (m): ");
                personData[i][1]=sc.nextDouble();
                if(personData[i][1]<=0)
                    System.out.println("Enter positive value");
            }while(personData[i][1]<=0);

            personData[i][2]=personData[i][0]/(personData[i][1]*personData[i][1]);

            if(personData[i][2]<18.5)
                weightStatus[i]="Underweight";
            else if(personData[i][2]<25)
                weightStatus[i]="Normal";
            else if(personData[i][2]<30)
                weightStatus[i]="Overweight";
            else
                weightStatus[i]="Obese";
        }

        for(int i=0;i<n;i++){
            System.out.println("Person "+(i+1));
            System.out.println("Weight = "+personData[i][0]+" kg");
            System.out.println("Height = "+personData[i][1]+" m");
            System.out.println("BMI = "+personData[i][2]);
            System.out.println("Status = "+weightStatus[i]);
        }
    }
}